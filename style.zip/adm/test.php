<?php
header('Access-Control-Allow-Origin: *');

include('db.php');

require('excel/php-excel-reader/excel_reader2.php');
require('excel/SpreadsheetReader.php');

$Reader = new SpreadsheetReader("products.xls");
$Sheets = $Reader->Sheets();
foreach ($Sheets as $Index => $Name)
{
    $Reader -> ChangeSheet($Index);
    foreach ($Reader as $Row)
    {
        print_r($Row);
        echo "<br><br>";
    }
}

?>